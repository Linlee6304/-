﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 專題ERP初步
{
	internal class DBHelper
	{
		public static string ConnStr = @"Data Source=LAPTOP-GD2BR52T\SQLEXPRESS;Initial Catalog=ERPSystem;Integrated Security=True;TrustServerCertificate=True;";
	}
}
